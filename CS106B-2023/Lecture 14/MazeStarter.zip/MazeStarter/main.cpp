#include <iostream>
#include "console.h"
#include "strlib.h"
#include "set.h"
#include "testing/SimpleTest.h"
#include "maze.h"
using namespace std;

void listSubsets(Set<std::string>& choices);

int main() {

    Grid<bool> maze;
    readMazeFile("res/13x39.maze", maze);
    solveMazeDFS(maze);

    return 0;
}
